import json,re,hashlib,shutil,tarfile
from pathlib import Path
root=Path(__file__).parent
summary=json.loads((root/'after-summary.json').read_text())
labels=['haiku','sonnet','glm-low','luna-low']
names={'haiku':'Anthropic claude-haiku-4-5','sonnet':'Anthropic claude-sonnet-4-6','glm-low':'Ollama glm-5.3-flash:cloud, think=low','luna-low':'OpenAI gpt-5.6-luna, reasoning_effort=low'}
baselines={'haiku':29,'sonnet':34,'glm-low':36,'luna-low':35}
lines=['# Issue #6 prompt evaluation','',
'The wording changes correct the output instructions, but these runs do not establish a reliability improvement. The fixed parser remains necessary. No production or PR source was changed during evaluation.','',
'## Comparison and scope','',
'- After: PR #10 commit `7d2dc2e1`. Before prompts: `d17b7a0c`. Both use the fixed parser.',
'- Historical full-suite baseline: `20260901-093840-s-tac-ahc`, dated 2026-09-01. Its `model-eval-matrix.md` attachment supplies the before totals and is included in the evidence bundle.',
'- Source comparison from `19c40958` to `d17b7a0c` found identical checker templates, embedded facts, and writing-guide fixtures. Pre-flight fixture changes only move the observation decorator import to `pkg/llm`; test inputs and assertions are unchanged. The baseline record names the same final gollm provider fixes.',
'- Each after suite ran 37 pre-flight cases and 3 writing-guide cases. Existing three-run checks were retained: 55 pre-flight calls and 9 writing-guide calls per model. Summarize and exploratory sweeps were excluded because their prompts were not changed.',
'- Full-suite before totals are historical, not a randomized paired experiment. The small brace panel is a fresh paired comparison, with identical user prompts verified from captured requests.',
'- API credentials came from the user-selected config through the existing harness. Keys are absent from this evidence bundle. Test-only Go overlays recorded requests and responses without changing the repository.',
'', '## Full-suite results','',
'| Model | Historical pre-flight | After pre-flight | After writing guide | Clean draft runs passing |',
'|---|---:|---:|---:|---:|']
for label in labels:
 d=summary[label]
 clean=re.search(r'pass rate (\d)/3 (?:below required|\(required) 3/3', (root/(label+'.log')).read_text().split('=== RUN   TestWritingGuideEval_CleanDraftStaysClean')[1])
 lines.append(f"| {names[label]} | {baselines[label]}/37 | {d['preflight']['passed']}/37 | {d['writing-guide']['passed']}/3 | {clean[1]}/3 |")
lines += ['', 'The historical writing-guide matrix already reports clean-draft failures for Haiku, Sonnet 4.6, and GLM low; Luna low passed all three cases. All models passed the stranding and conflation cases in this run. Every full-suite command exits nonzero because at least one behavioral assertion failed. These are not all-green evals.', '', '## Output format','', '| Model | Plain JSON responses, after suite | Checker parse/schema failures |', '|---|---:|---:|']
for label in labels:
 d=summary[label]; plain=sum(d[p]['plain_json'] for p in ['preflight','writing-guide'])
 lines.append(f"| {names[label]} | {plain}/64 | {'1' if label=='haiku' else '0'} |")
lines += ['', 'Haiku used surrounding Markdown or prose in all 64 responses. One response emitted `severity: "no-finding"`, which the existing severity validation correctly rejected. Sonnet used surrounding prose or fences in five responses; the parser recovered their JSON. GLM and Luna returned plain JSON throughout. Transport errors: zero recorded.', '', '## Fresh before/after brace panel','',
'Three inputs per model and prompt version: a pre-flight draft containing `Options{Zebra: true}`; a closing entry whose target contains that literal; and a writing-guide draft containing braces, ASCII quotes, and a Windows-style path. Assertions check checker parsing, not judgment accuracy. No model was instructed by the harness to add a preamble.','',
'| Model | Before parsed | After parsed | Before plain JSON | After plain JSON |', '|---|---:|---:|---:|---:|']
for label in labels:
 values=[]
 for phase in ['before','after']:
  rows=[json.loads(x) for x in (root/f'{label}-panel-{phase}.responses.jsonl').read_text().splitlines()]
  plain=0
  for r in rows:
   try:json.loads(r['Result']['Text']);plain+=1
   except ValueError:pass
  values.append(plain)
 lines.append(f'| {names[label]} | 3/3 | 3/3 | {values[0]}/3 | {values[1]}/3 |')
lines += ['', 'All 24 panel calls parsed successfully. Sonnet changed from one prose-wrapped response before to plain JSON after; one sample per input cannot establish a formatting benefit. Haiku remained noncompliant with the no-surrounding-text instruction on both versions. This panel did not reproduce the original bug with a live model; the deterministic regression tests reproduce that response shape.', '', '## Follow-up on the additional settled-decision misses','',
'The initial after suites missed `TestPreflightEval_Settled_Unjustified_Medium` on GLM and Sonnet. Only that case was checked again: three old-prompt calls, two new-prompt calls, reusing the initial new-prompt call as the third sample. This follow-up was selected after observing failures, so it is diagnostic rather than an unbiased rate estimate.', '',
'| Model | Old prompt | New prompt, including initial result | Interpretation |', '|---|---:|---:|---|',
'| GLM low | 3/3 | 2/3 | The initial miss did not repeat; no persistent regression demonstrated. |',
'| Sonnet 4.6 | 0/3 | 0/3 | The miss also occurs with the old prompt. |', '',
'Initial failures remain in the full-suite totals. Follow-ups do not replace them.', '', '## Failed full-suite cases','']
for label in labels:
 lines += ['### '+names[label], '']
 for purpose in ['preflight','writing-guide']:
  for name in summary[label][purpose]['failures']:lines.append('- `'+name+'`')
 lines += ['']
lines += ['## Run accounting and evidence','',
'290 recorded calls: 256 in four after suites, 24 in the matched brace panel, and 10 targeted follow-ups. No full before suite was repeated. Every test stream was saved in full; requests, responses, and per-call usage were retained. Provider usage columns differ in cache accounting and should not be compared as billing totals.','',
'| Model | Calls across all runs | Reported input tokens | Reported output tokens | Cache reads | Cache writes |', '|---|---:|---:|---:|---:|---:|']
for label in labels:
 paths=list(root.glob(label+'*/stats/llm.jsonl'))
 if label=='glm-low':paths+=list(root.glob('glm-delta-*/stats/llm.jsonl'))
 records=[json.loads(x) for p in paths for x in p.read_text().splitlines()]
 sums=[sum(r.get(k,0) for r in records) for k in ['input_tokens','output_tokens','cache_read_tokens','cache_create_tokens']]
 lines.append(f"| {names[label]} | {len(records)} | "+' | '.join(f'{n:,}' for n in sums)+' |')
lines += ['', 'Artifacts: `*.log` contain complete test output; `*.responses.jsonl` contain test names, rendered requests, results, and transport errors; `*/stats/llm.jsonl` contain usage; `after-summary.json` contains machine-readable suite results; `manifest.json` identifies source versions and artifact hashes. Temporary Go overlays and their source are included for reproduction.', '',
'The compiled test executables used the existing eval harness, with `SDD_EVAL_CONFIG`, `SDD_EVAL_PROVIDER`, `SDD_EVAL_MODEL`, `SDD_EVAL_PARAMS`, and distinct `SDD_EVAL_STATS_DIR` / `SDD_EVAL_TRACE_FILE` per run. Suite selector: `^(TestPreflightEval|TestWritingGuideEval)`. Brace selector: `^TestIssue6PromptEval$`. Follow-up selector: `^TestPreflightEval_Settled_Unjustified_Medium$`.', '',
'## Assessment','',
'The initial recommendation to retain the wording edits was withdrawn in dialogue: the observed full-suite totals were slightly worse, and no measured benefit offset the losses. The follow-ups do not establish that the new prompts are equally good. Following the confirmed direction, corrective commit 791cb44f reverted prompt-only commit 7d2dc2e1 while preserving parser fix d17b7a0c. The resulting llmops source matches d17b7a0c, and its tests pass. PR #10 remains unmerged. Future dialogue can revisit the wording weaknesses separately, using paired evaluations before restoring changes. The clean-draft false positives and settled-decision misses remain calibration concerns; this record does not claim they were fixed.','']
(root/'report.md').write_text('\n'.join(lines))
shutil.copyfile('/Users/hlubek/Dev/AI/Claude/sdd/.sdd/graph/2026/09/01-093840-s-tac-ahc/model-eval-matrix.md', root/'baseline-model-eval-matrix.md')
manifest=json.loads((root/'manifest.json').read_text())
manifest['artifact_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.suffix in ['.go','.tmpl','.test','.jsonl','.log']}
manifest['recorded_calls']=290
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(root/'evidence.tar.gz','w:gz') as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in ['.md','.json','.jsonl','.log','.go','.tmpl','.py']:
   archive.add(p,arcname=str(p.relative_to(root)))
print((root/'report.md').read_text())
