import json,re,statistics
from pathlib import Path
root=Path(__file__).parent
summary={}
for label in ['haiku','sonnet','glm-low','luna-low']:
 trace=root/(label+'.responses.jsonl'); log=root/(label+'.log')
 rows=[json.loads(x) for x in trace.read_text().splitlines()] if trace.exists() else []
 text=log.read_text() if log.exists() else ''
 cases=re.findall(r'^--- (PASS|FAIL): (Test\S+) \(([^)]*)\)',text,re.M)
 results={}
 for purpose,prefix in [('preflight','TestPreflightEval'),('writing-guide','TestWritingGuideEval')]:
  calls=[r for r in rows if r['Test'].startswith(prefix)]
  tests=[(outcome,name) for outcome,name,_ in cases if name.startswith(prefix)]
  strict=0; fenced=0; schema_errors=[]; transport=[]
  for r in calls:
   raw=r['Result']['Text']
   if r['Error']: transport.append({'test':r['Test'],'error':r['Error']}); continue
   try:
    obj=json.loads(raw); strict+=1
   except ValueError:
    match=re.fullmatch(r'\s*```(?:json)?\s*([\s\S]*?)\s*```\s*',raw)
    if not match: continue
    try: obj=json.loads(match[1]);fenced+=1
    except ValueError: continue
   findings=obj.get('findings') if isinstance(obj,dict) else None
   if not isinstance(findings,list): schema_errors.append(r['Test']);continue
   fields=['observation','category','severity'] if purpose=='preflight' else ['reasoning','axis','quote','repair','severity']
   severity=['high','medium','low'] if purpose=='preflight' else ['substantive','minor']
   if any(not isinstance(f,dict) or any(not isinstance(f.get(k),str) or not f[k].strip() for k in fields) or f.get('severity') not in severity for f in findings): schema_errors.append(r['Test'])
  results[purpose]={'calls':len(calls),'passed':sum(outcome=='PASS' for outcome,_ in tests),'cases':len(tests),'failures':[name for outcome,name in tests if outcome=='FAIL'],'plain_json':strict,'fenced_json':fenced,'schema_errors':schema_errors,'transport_errors':transport}
 statsfile=root/label/'stats/llm.jsonl'
 stats=[json.loads(x) for x in statsfile.read_text().splitlines()] if statsfile.exists() else []
 results['finished']=bool(re.search(r'^(PASS|FAIL)$',text,re.M))
 results['stats']=stats
 summary[label]=results
(root/'after-summary.json').write_text(json.dumps(summary,indent=2))
for label,data in summary.items():
 print(label, 'finished='+str(data['finished']))
 for purpose in ['preflight','writing-guide']:
  v=data[purpose];print(' ',purpose, f"{v['passed']}/{v['cases']} cases, {v['calls']} calls, plain JSON {v['plain_json']}, fenced JSON {v['fenced_json']}")
  for name in v['failures']: print('  FAIL',name)
